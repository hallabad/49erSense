Fall 2021 IOT Final Project - Phase 1
Authors: James Tallett, Hassan Al Labbad , [Hamza]

This part of the project is the android app
